


SPECIAL_CASES = {
    "donia": "Coriander",
    "tom": "Tomato",
    "green pepper": "pepper green",
    "red pepper": "pepper red",
    "spring onion": "onion spring",
    "spanish onion": "onion spanish"
}

def apply_special_cases(word: str) -> str | None:
    """
    Return mapped product if word matches a special case, else None.
    """
    return SPECIAL_CASES.get(word.strip().lower())